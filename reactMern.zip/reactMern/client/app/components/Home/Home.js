import React, {Component} from 'react';
import {getFromStorage, setInStorage} from "./../../utils/storage";
import 'whatwg-fetch';

class Home extends Component {
  constructor(props) {
    super(props);

    this.state = {
      isLoading: true,
      token: '',
      SignInError: "",
      SignUpError: "",
      SignInEmail: "",
      SignInPassword: "",
      SignUpEmail: "",
      SignUpFirstName: "" ,
      SignUpLastName: "",
      SignUpPassword: "",
      SignupError:""
    };
  }

  componentDidMount() {
    const token = getFromStorage('the_main_app');
    if (token) {
      fetch("/api/account/verify?=" + token)
        .then(res => res.json())
        .then(json => {
          if (json.success) {
            this.setState({token, isLoading: false})
          } else {
            this.setState({isLoading: false})
          }
        })
    } else {
      this.setState({isLoading: false})
    }
  }

  onTextboxChangeSignInEmail(event){
    this.setState({
      SignInEmail: event.target.value
    })
  }
  onTextboxChangeSignInPassword(event){
    this.setState({
      SignInPassword: event.target.value
    })
  }

  onTextboxChangeSignUpEmail(event){
    this.setState({
      SignUpEmail: event.target.value
    })
  }
  onTextboxChangeSignUpFirstName(event){
    this.setState({
      SignUpFirstName: event.target.value
    })
  }
  onTextboxChangeSignUpLastName(event){
    this.setState({
      SignUpLastName: event.target.value
    })
  }
  onTextboxChangeSignUpPassword(event){
    this.setState({
      SignUpPassword: event.target.value
    })
  }
  onSignIn(){
    const {
      SignInEmail,
      SignInPassword
    } = this.state;

    this.setState({
      isLoading: true
    })
    fetch("/api/account/signin", {
      method : 'POST',
      headers:{
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        email: SignInEmail,
        password: SignInPassword
      })
    })
      .then(res => res.json())
      .then(json => {
        if(json.success){
          this.setState({
            SignInError: json.message,
            isLoading: false,
            SignInEmail:"",
            SignInPassword:""
          })
        } else {
          this.setState({
            SignInError: json.message,
            isLoading: false
          })
        }
      })
  }
  onSignUp(){
    const {
      SignUpFirstName,
      SignUpLastName,
      SignUpEmail,
      SignUpPassword
    } = this.state;

    this.setState({
      isLoading: true
    })
    fetch("/api/account/signup", {
      method : 'POST',
      headers:{
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        firstName: SignUpFirstName,
        lastName: SignUpLastName,
        email: SignUpEmail,
        password: SignUpPassword
      })
    })
      .then(res => res.json())
      .then(json => {
        if(json.success){
          this.setState({
            SignupError: json.message,
            isLoading: false,
            SignUpFirstName:'',
            SignUpLastName:"",
            SignUpEmail:"",
            SignUpPassword:""
          })
        } else {
          this.setState({
            SignupError: json.message,
            isLoading: false
          })
        }
      })
  }
  render() {
    const {
      isLoading,
      token, 
      SignInEmail, 
      SignInPassword, 
      SignInError,
      SignupError,
      SignUpEmail,
      SignUpFirstName,
      SignUpLastName,
      SignUpPassword
    } = this.state;
    if (isLoading) {
      return (
        <div>
          <p>Loading...</p>
        </div>
      )
    }
    if (!token) {
      return (
        <div>
          <div>
          {
          (SignInError) ? (
            <p>{SignInError}</p>
          ) : (null)
        }
            <p>Sign In</p>
            <label htmlFor="mail">Email</label><br/>
            <input type="email" id="mail" placeholder="Email" value ={SignInEmail} onChange = {this.onTextboxChangeSignInEmail.bind(this)}/><br/>
            <label htmlFor="pswd">Password</label><br/>
            <input type="password" id="pswd" placeholder="Password" value = {SignInPassword} onChange = {this.onTextboxChangeSignInPassword.bind(this)}/><br/>
            <button onClick= {this.onSignIn.bind(this)}>Sign In</button>
          </div>
          <hr/>
          <hr/>
          <div>
          {
          (SignupError) ? (
            <p>{SignupError}</p>
          ) : (null)
        }
            <p>Sign Up</p>
            <label htmlFor="firstName">First Name</label><br/>
            <input type="text" id="firstName" placeholder="First Name" value ={SignUpFirstName} onChange = {this.onTextboxChangeSignUpFirstName.bind(this)} /><br/>
            <label htmlFor="lastName">Last Name</label><br/>
            <input type="text" id="lastName" placeholder="Last Name" value ={SignUpLastName} onChange = {this.onTextboxChangeSignUpLastName.bind(this)}/><br/>
            <label htmlFor="mail">Email</label><br/>
            <input type="email" id="mail" placeholder="Email" value ={SignUpEmail} onChange = {this.onTextboxChangeSignUpEmail.bind(this)}/><br/>
            <label htmlFor="pswd">Password</label><br/>
            <input type="password" id="pswd" placeholder="Password" value = {SignUpPassword} onChange = {this.onTextboxChangeSignUpPassword.bind(this)}/><br/>
            <button onClick= {this.onSignUp.bind(this)}> Sign Up</button>
          </div>
        </div>
      )
    }
    return (
      <div>Account</div>
    );
  }
}

export default Home;
